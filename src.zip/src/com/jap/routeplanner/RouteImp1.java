package com.jap.routeplanner;

public class RouteImp1 {
    public static void main(String[] args) {
        RoutePlanner routePlanner = new RoutePlanner();

        int count = routePlanner.countOfRoutes("routes.csv");
        Routes[] routes = routePlanner.readRoutes("routes.csv",count);
        //System.out.println(routes.length);
        System.out.println("Task one read data from csv and print\n\n");
        System.out.println("From          To    Distance    Travel Time    Airfare");
        for(Routes r:routes){

            System.out.println(r.toString());
        }
        System.out.println("Task two showDirect flights from a city\n\n");
        String fromCity="Delhi";
        routePlanner.showDirectFlights(routes,fromCity);
        System.out.println("Task three sort flights\n\n");

        routePlanner.sortDirectFlights(routes);

        System.out.println("Task four find fights ");

        routePlanner.showFlights(routes,"Delhi","London");
    }

}
